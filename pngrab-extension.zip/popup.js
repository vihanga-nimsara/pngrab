document.addEventListener('contextmenu', (e) => e.preventDefault(), { capture: true });
document.addEventListener('dragstart', (e) => e.preventDefault(), { capture: true });
document.addEventListener('selectstart', (e) => e.preventDefault(), { capture: true });
